<?php
session_start();
include_once __DIR__.'/config.php';
class user{
    var $db;
    public function __construct()
    {
        $this->db = new _pdo();
        $this->db = $this->db->connect();
    }

    public function login()
    {
        if(empty($_POST))
        {
            include_once __DIR__ . '/login_form.php';
            die;
        }

        $name = trim($_POST['name']) ? trim($_POST['name']) : '';
        $pwd = trim($_POST['pwd']) ? md5(trim($_POST['pwd'])) : '';
        if($name && $pwd)
        {
            $sql = 'select * from user where name="'.$name.'" and password="'.$pwd.'"';
            $res = $this->db->query($sql);
            $res = $res->fetch();
            if($res)
            {
                $_SESSION['user_name'] = $name;
                include_once __DIR__.'/login.php';
            }else{
                echo WRONG;
            }
        }else{
            echo NULL_M;
        }
    }

    public function login_by_access_token()
    {

    }

    public function logout()
    {
        session_unset();
        session_destroy();
        include_once __DIR__.'/login.php';

    }
}
$obj = new user();
$a = trim($_REQUEST['a']) ? trim($_REQUEST['a']) : '';
if($a)
{
    $obj->$a();
}else{
    $obj->login();
}