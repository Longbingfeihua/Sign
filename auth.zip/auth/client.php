<?php
include_once('./curl.class.php');
include_once('./config.php');
class idtentify
{
	var $curl;
	var $access_token;
	var $refresh_token;
	var $scope;
	public function __construct()
	{
		$this->curl = new curl();
	}

	public function index()
	{

	}
	public function get_access_token()
	{
		$code = trim($_REQUEST['code']) ? trim($_REQUEST['code']) : '';
		$state = trim($_REQUEST['state']) ? trim($_REQUEST['state']) : '';
		$redirect_uri = urlencode(REDIRECT_URI);
		if($code && $state == STATE)
		{
			$data = array(
				'grant_type'=>'authorization_code',
				'redirect_uri' => $redirect_uri,
				'code' => $code,
			);
			$this->curl->unset_curl();
			$this->curl->setPassword(CLIENT_ID,CLIENT_SECRET);
			$this->curl->setUrl(TOKEN_URI);
			$this->curl->addData($data);
			$res = $this->curl->curlExec();
			if($res)
			{
				$arr = json_decode($res,1);
				$this->access_token = $arr['access_token'];
				$this->refresh_token = $arr['refresh_token'];
				$this->get_user_info();
			}
		}
	}

	public function get_user_info()
	{
		$data = array(
			'access_token' => $this->access_token,
		);
		$this->curl->unset_curl();
		$this->curl->setUrl(RESOUECE_URI);
		$this->curl->setHeader('Content-Type:application/x-www-form-urlencoded');
		$this->curl->addData($data);
		$res = $this->curl->curlExec();
		//var_dump($res);die;
		if($res)
		{
			$userinfo = json_decode($res,1);
			$_SESSION['user_name'] = $userinfo['name'];
			include_once __DIR__.'/login.php';
		}
	}

}

$obj = new idtentify();
if($_REQUEST['a'])
{
	$obj->$_REQUEST['a']();
}else{
	$obj->index();
}
