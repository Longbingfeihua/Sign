<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>client登录</title>
    <style>
        .auto{margin:0 auto; text-align:center}
        .div,input{margin-top:20px;}
    </style>
</head>
<body>
<div class="auto div">
    <form method="post" action="./user.php">
        <label>client登录</label><br/>
        用户名：<input type="input" name="name"><br/>
        密之码：<input type="password" name="pwd"><br/>
        <input type="submit" name="sub" value="登录">
    </form>
</div>
</body>
</html>