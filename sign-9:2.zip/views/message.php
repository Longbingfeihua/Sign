<script src="<?= BASE_URL ?>/public/js/message.js"></script>
<div class="message_main">
	<div class="message_div auto">
		<div class="message_tip">
			<url class="message_nav">
				<li class="message_eye"><span class="glyphicon glyphicon-eye-open" title="点击改变聊天框颜色"></span></li>
				<li class="message_save"><span class="glyphicon glyphicon-floppy-save" title="将聊天记录保存到本地"></span></li>
				<li><span class="glyphicon glyphicon-text-height"></span></li>
				<li class="message_remove"><span class="icon-trash" title="清空聊天记录"></span></li>
			</url>
		</div>
		<div class="message_body">
		</div>
		<div class="message_style">
			<url class="nav_style">
				<li class="italic" on="false"><span class="glyphicon glyphicon-italic" title="斜体"></span></li>
				<li class="bold" on="false"><span class="glyphicon glyphicon-bold" title="加粗"></span></li>
				<li class="font" on="false"><span class="glyphicon glyphicon-font" title="大小"></span></li>
			</url>
		</div>
		<div class="message_tool">
			<textarea class="message_area"></textarea>
		</div>
	</div>
</div>