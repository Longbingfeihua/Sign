<?php
//资源控制器/用access_token来获取资源
// include our OAuth2 Server object
include_once __DIR__.'/config.php';
require_once __DIR__.'/server.php';

// Handle a request for an OAuth2.0 Access Token and send the response to the client
if (!$server->verifyResourceRequest(OAuth2\Request::createFromGlobals())) {
    $server->getResponse()->send();
    die('Code usable');
}

//服务端可以根据access_token判断第三方在使用哪个用户的资料
$token = $server->getAccessTokenData(OAuth2\Request::createFromGlobals());
$user_id = $token['user_id'];
$scope = $token['scope'] ? $token['scope'] : '';

$obj = new _pdo();
$pdo = $obj->connect();
if($scope)
{
    $scope = explode(' ',$scope);
    $arr = array();
    foreach($scope as $vo)
    {
        foreach($GLOBALS['scopes'] as $k => $v)
        {
            if($vo == $k)
            {
                $arr[] = $v;
            }
        }
    }
    if(!empty($arr))
    {
        $str = implode(',',$arr);
        $sql = "SELECT {$str} from resource where name='".$user_id."'";
        $res = $pdo->query($sql)->fetch(PDO::FETCH_ASSOC);
        if($res)
        {
            $res['result'] = 'success';
            echo json_encode($res);
        }
    }else{
        echo '{"result":"failed"}';
    }
}