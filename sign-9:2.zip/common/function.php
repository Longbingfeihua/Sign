<?php
/**
 * Created by PhpStorm.
 * User: zhangxian
 * Date: 15/7/8
 * Time: 上午8:54
 */

/*
 * 报错
 */
function ShowError($error,$url = "")
{
    if($error)
    {
        Header("Location:".BASE_URL."/common/error/generalError.php?error=$error&url=$url");
    }else
    {
        echo 'Error Info Is Null!';
        exit;
    }
}

/*
 * 权限验证
 */
function Identify ()
{
    if(!isset($_SESSION['username']))
    {
        ShowError(LOGIN_FIRST,BASE_URL);
    }
}

/*
* 对于redis数据进行反序列化
*/

function unse($data)
{
	if(!$data)
	{
		return array();
	}
	if(!is_array($data))
	{
		return unserialize($data);
	}
	foreach($data as $key => $vo)
	{
		$return[$key] = unserialize($vo);
	}
	return $return;
}

/*
* redis callback函数
*/

