<?php
/*@curl操作类，包含文件上传,array,json,xml数据传输。
* @$return;
*/
class curl{
	var $url;
	var $type = 'GET';
	var $data = array();
	var $is_header = 0;
	var $header = array('Expect:');
	var $is_nobody = 0;
	var $is_return = true;
	var $timeOut = 30;//s
	var $username = '';
	var $password = '';
	var $curlInfo = array();
	
	public function __construct(){}
	
	public function setUrl($host,$dir = '')
	{
		$this->url = $host.$dir;
	}
	
	public function setType($type)
	{
		$this->type = $type;
	}
	
	public function addData($data)
	{   
		$this->type = 'POST';
		$this->data = array(); //初始化data

		if(!is_array($data))
		{   
			if(trim($data))
			{
				$this->data['String'] = trim($data);
				return;
			}else{
				return 'WRONG_DATA';
			}
		}
		
		foreach($data as $name =>$value)
		{
			if($name !== 'curlFiles') //如果键名设置为curlFiles可以自动识别为@
			{
				$this->data[$name] = $value;
			}else
			{
				if(!file_exists($value))
				{
					return 'FILE_NOT_EXISTS';
				}
				if(PHP_VERSION <5.5)
				{
					$value = '@'.$value; //value为绝对路径
				}else{
					$value = curl_file_create($value);//value为脚本相对路径
				}
				$this->data['curlFiles']= $value;
			}
		}		
	}
	
	public function postXml($xmlString)//body接受用$GLOBALS['HTTP_RAW_POST_DATA']；或php://input输入流；
	{	
		$this->setHeader('Content-Type:text/xml');
		$this->type = 'POST';
		$this->data = $xmlString;
	}
	
	public function postJson($jsonString)//body接受用$GLOBALS['HTTP_RAW_POST_DATA'] PHP_VERSION<5.6；或php://input输入流；
	{
		$this->setHeader('Content-Type:application/json');
		$this->type = 'POST';
		$this->data = $jsonString;
	}
	
	public function setHeader($data)
	{
		if(is_array($data))
		{
			foreach($data as $vo)
			{
				$this->header[] = $vo;//默认
			}
		}else{
			$this->header[] = $data;
		}
	}

	public function setPassword($username,$password)
	{
		$this->username = $username;
		$this->password = $password;
	}
	public function curlExec()
	{
		$ch = curl_init();
		
		if(!$this->url)
		{
			return 'URL_IS_NULL';
		}
		curl_setopt($ch, CURLOPT_URL, $this->url);
		curl_setopt($ch, CURLOPT_HEADER, $this->is_header);//是否显示头
		curl_setopt($ch, CURLOPT_NOBODY, $this->is_nobody);//是否显示body
		curl_setopt($ch, CURLOPT_HTTPHEADER, $this->header);//http请求header
		curl_setopt($ch,CURLOPT_AUTOREFERER,1);

		if($this->username && $this->password) {
			//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
			curl_setopt($ch, CURLOPT_USERPWD, "$this->username:$this->password"); //需要账号密码登录的地址
		}

		if(strtoupper($this->type) === 'POST')
		{
			curl_setopt($ch, CURLOPT_POST,true);
			curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($this->data));
		}
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, $this->is_return);//返回还是直接显示
		curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeOut);

		$return = curl_exec($ch);
		$this->curlInfo = curl_getinfo($ch);
		curl_close($ch);

		return $return;		
	}

	public function unset_curl()
	{
		$this->url = '';
		$this->type = 'GET';
		$this->data = array();
		$this->is_header = 0;
		$this->header = array('Expect:');
		$this->is_nobody = 0;
		$this->is_return = true;
		$this->timeOut = 30;//s
		$this->username = '';
		$this->password = '';
		$this->curlInfo = array();
	}
}