<?php
//token控制器
//eg:b0d3d4604ca209d18c197c034596d69661658ec2;
// include our OAuth2 Server object
require_once __DIR__.'/server.php';
 
// Handle a request for an OAuth2.0 Access Token and send the response to the client
$server->handleTokenRequest(OAuth2\Request::createFromGlobals())->send();

