<div class="sign_main_div">
<?php print_r($_SESSION);?>
<!--
	<div class="sign_home_circle_div" id="sign_main_circle_div">
		<?php foreach($detail as $vo){?>
			<a href=""><?= $vo['name'].'.'.$vo['address'];?></a>
		<?php } ?>
	</div>
-->
</div>