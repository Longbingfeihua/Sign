<?php
class curl
{
    var $a = 1;
}