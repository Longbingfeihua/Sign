<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>登录</title>
<style>
    .auto{
        margin:0 auto;
    }
    .title_div{
        width:1000px;
        height:60px;
        border:1px solid grey;
        /*line-height: 60px;*/
    }
    .nav1{
        list-style-type: none;;
    }
    .nav1 li{
        width:150px;
        height:30px;
        float:right;
        margin-left: 10px;
        line-height: 30px;
        text-align: center;
    }

    .nav1 li a{
        height:20px;
        text-decoration: none;
    }
</style>
</head>
<body>
    <div class="title_div auto">
        <ul class="nav1">
            <?php if(!isset($_SESSION['user_name'])){?>
            <li><a href="http://localhost/auth/server/authorize.php?response_type=code&client_id=hoge2&state=xyz&redirect_uri=http://localhost/auth/client.php?a=get_access_token">使用QQ登录</a></li>
            <li><a href="./user.php?a=login">登录</a></li>
            <?php }else{ ?>
            <li><a href="./user.php?a=logout">退出</a></li>
            <li>欢迎你：<span><?= $_SESSION['user_name']?></span></li>
            <?php } ?>
        </ul>
    </div>
</body>
</html>
