<?php
	define('REDISHOST','127.0.0.1');
	define('REDISPORT',6379);
	define('REDISPWD',1234);
	class db
	{
		public function redisConnect()
		{
			$redis = @new redis();
			$connect = $redis->connect(REDISHOST,REDISPORT);
			if(!$connect)
			{
				showError('Redis connect failed! start redis server firstly!',BASE_URL);
			}
			return $redis;
		}
	}