<?php
//define('REGIST_SUCCESSFULLY','注册成功!');
define('LOGIN_SUCCESSFULLY','登录成功!');
define('LOGIN_FIRST','此权限必须登录');