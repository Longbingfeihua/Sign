<?php
//授权控制器
//验证用户名和密码。
//生成30s临时令牌/用于到token控制器获得access_token。
// include our OAuth2 Server object
require_once __DIR__.'/server.php';
$request = OAuth2\Request::createFromGlobals();
$response = new OAuth2\Response();
// validate the authorize request
if (!$server->validateAuthorizeRequest($request, $response)) {
    $response->send();
    die;
}
// display an authorization form
if (!isset($_POST['sub']) && isset($_REQUEST['client_id']) && $storage->getClientDetails(trim($_REQUEST['client_id']))) {
    $client_id = trim($_REQUEST['client_id']);
    $state = trim($_REQUEST['state']);
    $redirect_uri = trim($_REQUEST['redirect_uri']);?>
<html>
<head>
<style>
    .auto{margin:0 auto; text-align:center}
    .div,input{margin-top:20px;}
</style>
</head>
<body>
    <div class="auto div">
        <form method="post" action="http://localhost/auth/server/authorize.php?response_type=code">
            <label>QQ登录</label><br/>
            用户名：<input type="input" name="name"><br/>
            密之码：<input type="password" name="pwd"><br/>
            <input type="hidden" name="client_id" value="<?=$client_id ?>">
            <input type="hidden" name="state" value="<?=$state ?>">
            <input type="hidden" name="redirect_uri" value="<?=$redirect_uri ?>">
            <input type="submit" name="sub" value="登录">
        </form>
    </div>
</body>
</html>

<?php die;}

$user_name = trim($_POST['name']);
$password = trim($_POST['pwd']);
$is_authorized = $storage->checkUserCredentials($user_name,$password);

$user_details = $storage->getUserDetails($user_name);
//$storage->getUser($_POST['name'])
// print the authorization code if the user has authorized your client

//the user_id for your client user
//$user_id =$user_details[''];

$server->handleAuthorizeRequest($request, $response, $is_authorized,$user_details['user_id']); //可以传入user_id
if ($is_authorized) {
    // this is only here so that you get to see your code in the cURL request. Otherwise, we'd redirect back to the client
    $code = substr($response->getHttpHeader('Location'), strpos($response->getHttpHeader('Location'), 'code=')+5, 40);
    //header("location:$code");
}else{
    echo 123;
}
$response->send();