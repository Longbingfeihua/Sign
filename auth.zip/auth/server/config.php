<?php
/**
 * Created by PhpStorm.
 * User: mac
 * Date: 15/9/22
 * Time: 上午8:48
 */
define('DSN','mysql:host=127.0.0.1;dbname=resource');
define('USERNAME','root');
define('PASSWORD','1234');
$GLOBALS['scopes'] = array(
    1 => 'name',
    2 => 'tel',
    3 => 'address',
);
class _pdo
{
    public function connect()
    {

        $pdo = new PDO(DSN,USERNAME,PASSWORD);
        return $pdo;
    }
}