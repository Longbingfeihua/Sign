<?php
define('MOD','Discuss');
class Discuss extends BaseCore{
	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function index()
	{
		
		$this->load->view('head');
		$this->load->view('Discuss');
		$this->load->view('footer');
	}
}