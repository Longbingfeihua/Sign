<?php
/**
 * client & user regist
 * Created by PhpStorm.
 * User: sign
 * Date: 15/9/21
 * Time: 下午4:21
 */
include_once __DIR__.'/server.php';
$GLOBALS['storage'] = $storage;

class regist{
    var $name;
    var $password;
    var $oauth;
    var $redirect_uri;
    var $grant_types;
    var $scope;
    var $user_id;

    public function __construct(){
        if(trim($_REQUEST['name']))
        {
            $this->name = trim($_REQUEST['name']);
        }else
        {
            return 'NO_NAME';
        }

        if(trim($_REQUEST['pwd']))
        {
            $this->password = trim($_REQUEST['pwd']);
        }else
        {
            return 'NO_PWD';
        }

        if(trim($_REQUEST['a']) == 'client_regist')
        {
            if(trim($_REQUEST['redirect_uri']))
            {
                $this->redirect_uri = $_REQUEST['redirect_uri'];
            }

            if($_REQUEST['scope'])
            {
                $this->scope = implode(',',$_REQUEST['scope']);
            }
        }

        $this->oauth =  $GLOBALS['storage'];

    }
    public function index()
    {
        include_once __DIR__ . 'user_regist.html';
    }

    public function user_regist()
    {
        if($this->oauth->getUser($this->name))
        {
            die('此账号名已被注册！');
        }
        $res = $this->oauth->setUser($this->name,$this->password);
        if($res)
        {
            echo 'REGIST_SUCCESSFULLY';
        }
    }

    public function client_regist()
    {
        if($this->oauth->getClientDetails($this->name))
        {
            die('此账号名已被注册！');
        }
        $res = $this->oauth->setClientDetails($this->name,$this->password,$this->redirect_uri,null,$this->scope,null);
        if($res){
            echo 'REGIST_SUCCESSFULLY';
        }
    }
}

$obj = new regist();
$a = trim($_REQUEST['a']) ? trim($_REQUEST['a']) : '';
if($a)
{
    $obj->$a();
}else
{
    $obj->regist();
}