<?php
/**
 * Created by PhpStorm.
 * User: mac
 * Date: 15/9/22
 * Time: 上午8:48
 */
define('CLIENT_ID','hoge2');
define('CLIENT_SECRET','321');
define('REDIRECT_URI','http://localhost/auth/client.php?a=get_access_token');
define('TOKEN_URI','http://localhost/auth/server/token.php');
define('RESOUECE_URI','http://localhost/auth/server/resource.php');
define('STATE','xyz');
define('DSN','mysql:host=127.0.0.1;dbname=client_user');
define('USERNAME','root');
define('PASSWORD','1234');
define('WRONG','账号名密码错误');
define('NULL_M','账号名密码为空');

class _pdo
{
    public function connect()
    {

        $pdo = new PDO(DSN,USERNAME,PASSWORD);
        return $pdo;
    }
}